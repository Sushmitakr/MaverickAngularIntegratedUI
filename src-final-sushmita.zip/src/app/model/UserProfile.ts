export class User {
    userId: number
    userName: string
    password: string
    email: string
    location: string
    mobile: number
    gender: string
    age: number
    role: string
}