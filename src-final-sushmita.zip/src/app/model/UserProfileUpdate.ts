export class UserUpdate {
    userId: number
    userName: string
    password: string
    email: string
    age: number
    mobile: number
    role: string
    image: string
    coverImage: string
    gender: string
    location: string
    level: number
    levelName: String
    aboutMe: string
    status: string
    gameCount: string
}