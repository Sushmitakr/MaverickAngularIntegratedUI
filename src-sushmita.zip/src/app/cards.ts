// tslint:disable:max-line-length
export const cards = [
  {
    title: 'Ipsum duis sint incididunt',
    text: 'Consectetur minim et et consectetur voluptate irure tempor qui anim'
  },
  {
    title: 'Qui ipsum consequat cillum occaecat nulla',
    text: 'Incididunt dolore duis Lorem non fugiat sint culpa non duis tempor laborum ex'
  },
  {
    title: 'Irure Lorem dolore est adipisicing aliqua',
    text: 'Aliquip cillum qui eu ullamco nulla ad pariatur aliqua deserunt laboris laborum laboris eiusmod. Aliquip cillum qui eu ullamco nulla ad pariatur aliqua deserunt laboris laborum laboris eiusmod'
  },
  {
    title: 'Quis duis cillum cupidatat qui ex aliqua',
    text: 'Adipisicing ipsum est'
  },
  {
    title: 'Consequat labore laboris aute',
    text: 'Consectetur minim et et consectetur voluptate irure tempor qui anim. voluptate proident cillum aute dolor elit exercitation'
  },
  {
    title: 'Et nulla culpa',
    text: 'excepteur deserunt cillum excepteur Lorem consectetur duis elit minim id pariatur eiusmod'
  },
  {
    title: 'Cupidatat proident',
    text: 'Nisi voluptate duis est duis cillum sint eu nisi laboris eu nisi labore et incididunt consectetur dolor quis Nisi voluptate duis est duis cillum sint eu nisi laboris eu nisi labore et incididunt consectetur dolor quis'
  },
  {
    title: 'Adipisicing veniam',
    text: 'voluptate veniam officia irure sit consequat do cillum exercitation laborum elit'
  },
  {
    title: 'Duis et ea duis',
    text: 'aliqua fugiat mollit'
  },
  {
    title: 'Aliqua excepteur',
    text: 'Cupidatat irure ut est cupidatat ipsum exercitation duis deserunt magna mollit elit commodo anim'
  }
];
// tslint:enable:max-line-length
