import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-game',
  templateUrl: './recent-game.component.html',
  styleUrls: ['./recent-game.component.css']
})
export class RecentGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
