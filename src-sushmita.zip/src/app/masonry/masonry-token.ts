import { InjectionToken } from '@angular/core';

export const Masonry = new InjectionToken<string>('Masonry');
