export class cModel{
    categoryId: number
    categoryName: string
}