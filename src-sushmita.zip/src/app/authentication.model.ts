export class AuthenticationModel{
    userId: number
    userName: string
    password: string
    email: string
    location: string
    mobile: string
    gender: string
    age: string
    role: string
}